
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';

// Component nút bấm
const CustomButton = ({ title, onPress, color }) => {
  return (
    <TouchableOpacity
      style={[styles.button, { backgroundColor: color }]}
      onPress={onPress}
    >
      <Text style={styles.buttonText}>{title}</Text>
    </TouchableOpacity>
  );
};

// Component thẻ thông tin
const InfoCard = ({ title, description, icon }) => {
  return (
    <View style={styles.card}>
      <Text style={styles.cardIcon}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <Text style={styles.cardTitle}>{title}</Text>
        <Text style={styles.cardDescription}>
          {description}
        </Text>
      </View>
    </View>
  );
};

// Ứng dụng chính
export default function App() {
  const [name, setName] = useState('');
  const [count, setCount] = useState(0);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>

        {/* Tiêu đề */}
        <View style={styles.header}>
          <Text style={styles.logo}>📱 MyApp_V2</Text>
          <Text style={styles.subtitle}>
            Ứng dụng thực hành React Native
          </Text>
        </View>

        {/* Giới thiệu */}
        <View style={styles.banner}>
          <Text style={styles.bannerTitle}>
            Xin chào! 👋
          </Text>
          <Text style={styles.bannerText}>
            Chào mừng bạn đến với ứng dụng MyApp_V2.
            Cùng khám phá các thành phần giao diện nhé!
          </Text>
        </View>

        {/* Nhập thông tin */}
        <Text style={styles.sectionTitle}>
          Thông tin cá nhân
        </Text>

        <View style={styles.inputBox}>
          <Text style={styles.label}>Nhập họ và tên:</Text>
          <TextInput
            style={styles.input}
            placeholder="Nhập tên của bạn..."
            value={name}
            onChangeText={setName}
          />

          <Text style={styles.result}>
            {name ? `Xin chào, ${name}!` : 'Chưa có thông tin'}
          </Text>
        </View>

        {/* Danh sách Component */}
        <Text style={styles.sectionTitle}>
          Các thành phần giao diện
        </Text>

        <InfoCard
          icon="🎨"
          title="View và Text"
          description="Sử dụng để tạo bố cục và hiển thị nội dung."
        />

        <InfoCard
          icon="⌨️"
          title="TextInput"
          description="Cho phép người dùng nhập dữ liệu."
        />

        <InfoCard
          icon="🔘"
          title="TouchableOpacity"
          description="Tạo nút bấm có thể tương tác."
        />

        {/* Bộ đếm */}
        <Text style={styles.sectionTitle}>
          Thử tương tác
        </Text>

        <View style={styles.counterBox}>
          <Text style={styles.counterTitle}>
            Số lần nhấn nút
          </Text>

          <Text style={styles.counter}>
            {count}
          </Text>

          <CustomButton
            title="NHẤN VÀO ĐÂY"
            color="#2563EB"
            onPress={() => setCount(count + 1)}
          />

          <CustomButton
            title="ĐẶT LẠI"
            color="#64748B"
            onPress={() => setCount(0)}
          />
        </View>

        {/* Chân trang */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            MYAPP_V2
          </Text>
          <Text style={styles.footerSub}>
            Bài thực hành React Native
          </Text>
          <Text style={styles.footerSub}>
            © 2026 - Expo Snack
          </Text>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

// Định dạng giao diện
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F1F5F9',
  },

  header: {
    backgroundColor: '#1E40AF',
    padding: 25,
    paddingTop: 35,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
  },

  logo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },

  subtitle: {
    color: '#DBEAFE',
    fontSize: 14,
    marginTop: 8,
  },

  banner: {
    backgroundColor: '#DBEAFE',
    margin: 18,
    padding: 20,
    borderRadius: 15,
  },

  bannerTitle: {
    fontSize: 23,
    fontWeight: 'bold',
    color: '#1E40AF',
    marginBottom: 8,
  },

  bannerText: {
    fontSize: 15,
    color: '#334155',
    lineHeight: 23,
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: 'bold',
    color: '#1E293B',
    marginHorizontal: 18,
    marginTop: 15,
    marginBottom: 12,
  },

  inputBox: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 18,
    padding: 18,
    borderRadius: 15,
  },

  label: {
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 10,
    color: '#334155',
  },

  input: {
    borderWidth: 1,
    borderColor: '#CBD5E1',
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    backgroundColor: '#F8FAFC',
  },

  result: {
    color: '#2563EB',
    marginTop: 12,
    fontWeight: 'bold',
  },

  card: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 18,
    marginBottom: 12,
    padding: 17,
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
  },

  cardIcon: {
    fontSize: 30,
    marginRight: 15,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E293B',
  },

  cardDescription: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 5,
  },

  counterBox: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 18,
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
  },

  counterTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#334155',
  },

  counter: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#2563EB',
    marginVertical: 12,
  },

  button: {
    width: '100%',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },

  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 15,
  },

  footer: {
    backgroundColor: '#1E293B',
    padding: 25,
    marginTop: 25,
    alignItems: 'center',
  },

  footerText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 20,
  },

  footerSub: {
    color: '#CBD5E1',
    marginTop: 7,
    fontSize: 13,
  },
});
