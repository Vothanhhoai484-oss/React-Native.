BÀI TẬP 01: THIẾT KẾ GIAO DIỆN REACT NATIVE
1. Thông tin bài tập
Tên bài nộp: MyApp_V2
Môn học: React Native
Bài: Bài 2 - Xây dựng giao diện ứng dụng với React Native
Công cụ: Expo Snack
2. Link ứng dụng Expo

Truy cập ứng dụng MyApp_V2

3. Cấu trúc chương trình
App.js: Component chính của ứng dụng.
Header.js: Component tiêu đề.
Main.js: Component nội dung chính.
Footer.js: Component chân trang.
4. Các dòng code và hình ảnh thay đổi giao diện của các thành phần trong Component
4.1. Header Component

Code:

jsx
<Text style={styles.logo}>📱 MyApp_V2</Text>


Hình ảnh:

!Header

4.2. Main Component

Code:

jsx
<Text style={styles.title}>Xin chào!</Text>

<TextInput
  style={styles.input}
  placeholder="Nhập tên của bạn..."
  value={name}
  onChangeText={setName}
/>


Hình ảnh:

!Main

4.3. Button Component

Code:

jsx
<TouchableOpacity
  style={styles.button}
  onPress={() => setCount(count + 1)}
>
  <Text style={styles.buttonText}>TĂNG SỐ</Text>
</TouchableOpacity>


Hình ảnh:

!Button

4.4. Footer Component

Code:

jsx
<Text style={styles.title}>MYAPP_V2</Text>
<Text style={styles.text}>Bài thực hành React Native</Text>


Hình ảnh:

!Footer

5. Hình ảnh giao diện toàn bộ ứng dụng

!MyApp_V2

6. Kết luận

Đã hoàn thành bài thực hành xây dựng giao diện ứng dụng với React Native.

Ứng dụng sử dụng các Component Header, Main, Footer và các thành phần View, Text, TextInput, TouchableOpacity, ScrollView.

Đã thực hiện thay đổi màu sắc, kích thước chữ, bố cục, khoảng cách và chức năng tương tác của giao diện.